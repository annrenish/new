/**
 *
 */
package uk.co.jemos.podam.test.dto;

/**
 * POJO to test Class instantiation
 *
 * @author daivanov
 *
 */
public class ClassInheritedPojo extends ClassGenericPojo<String> {
}
