/**
 * 
 */
package uk.co.jemos.podam.test.dto;

import java.util.Map;

/**
 * Test pojo
 * <p>
 * Pojo extending Pojo with generic interface.
 * </p>
 * 
 * @author daivanov
 * 
 */
@SuppressWarnings("rawtypes")
public interface PodamRawMap extends Map {
}
