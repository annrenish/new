/**
 * Contains stories for extending Podam.
 *
 * Created by tedonema on 31/05/2015.
 *
 * @since 5.5.0
 *//**
 * Created by tedonema on 07/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.extensions;